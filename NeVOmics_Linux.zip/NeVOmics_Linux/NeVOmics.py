#!/usr/bin/env python3

import tkinter
from tkinter import * 
from tkinter.ttk import *
from tkinter import Tk, Label, Button, Radiobutton, IntVar
import tkinter as tk
import io
import base64
try:
    # Python2
    import Tkinter as tk
    from urllib2 import urlopen
except ImportError:
    # Python3
    import tkinter as tk
    from urllib.request import urlopen

def ask_multiple_choice_question(prompt, options):
    root = Tk()
    root.title("NeVOmics")
    root.geometry("850x540")
    root.overrideredirect(1)
    Label(root, text="").pack()
    image_url = "https://raw.githubusercontent.com/eduardo1011/Programas/master/NeVOmics_logo.gif"
    image_byt = urlopen(image_url).read()
    image_b64 = base64.encodestring(image_byt)
    logo1 = tk.PhotoImage(data=image_b64)
    w1 = tk.Label(root, image=logo1).pack()

    if prompt:
        
        #logo = tk.PhotoImage("\n",file="ne3.gif") para imagen en directorio
        #w1 = tk.Label(root, image=logo).pack()

        Label(root, text="\nIf you use NeVOmics in your research, please cite:      ",font=("Arial", 11)).pack()
        Label(root, text="NeVOmics: an enrichment tool for gene ontology and functional\n"+
        "network analysis and visualization of data from OMICs technologies",font=("Arial", 11),bg="pale green").pack()
        Label(root, text="\n[ Functional Enrichment Analysis ]\n",font=("Arial", 15)).pack()
    v = IntVar()
    for i, option in enumerate(options):
        Radiobutton(root, text=option,font=("Arial", 13, "bold"),bg="gold2", variable=v, value=i).pack()

    Button(root,text="          Submit          ",bg="black", fg="white",font=("Arial", 11), command=root.destroy).pack(pady=15) #anchor must be n, ne, e, se, s, sw, w, nw, or center
    root.mainloop()						             #pady  separacion entre la tercer linea y submit
    if v.get() == 0: return None
    return options[v.get()]


result = ask_multiple_choice_question(" ",
    [
        "   None     ",
        "    1    GO Enrichment       ",
        "    2    KEGG Pathways Enrichment       ",
        "    3    KEGG Pathways Enrichment using blast[p/x]       "
    ]
)
if format(repr(result)) == 'None':
    print('\nNo analysis was selected')
    sys.exit()
else:
    print('\n',result)
    import urllib.request
    from urllib.request import urlopen
    import sys
    import requests
    import subprocess
    import os

    if float(re.findall('[0-9]{1}',format(repr(result)))[0]) == 1:
        urllib.request.urlretrieve('https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/GO_Ubuntu.py', './GO.py')
        urllib.request.urlretrieve('https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/HD.py', './HD.py')
        subprocess.call(['python3','GO.py'])
    else:
        if float(re.findall('[0-9]{1}',format(repr(result)))[0]) == 2:
            urllib.request.urlretrieve('https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/KEGG_Ubuntu.py', './KEGG.py')
            urllib.request.urlretrieve('https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/HD.py', './HD.py')
            subprocess.call(['python3','KEGG.py'])
        else:
            if float(re.findall('[0-9]{1}',format(repr(result)))[0]) == 3:
                urllib.request.urlretrieve("https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/KEGG_BLAST_Ubuntu.py",'./KEGG_BLAST.py')
                urllib.request.urlretrieve('https://raw.githubusercontent.com/bioinfproject/bioinfo/master/Folder/HD.py', './HD.py')
                subprocess.call(['python3','KEGG_BLAST.py'])
                sys.exit()
